export interface Auth {
}
